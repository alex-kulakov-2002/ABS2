#ifndef __exceptions__
#define __exceptions__

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

class ProgramException {
public:
    static bool GetInt(FILE* inputFile, int* number);

    static void errMessage2();

    static void errMessage1();
};


#endif