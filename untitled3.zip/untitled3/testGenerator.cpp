#include "testGenerator.h"


void TestGeneretor::generateTest(int size) {
    FILE* inputFile = fopen("testAutomaticGenerate.txt", "w");
    for (int i = 0; i < size; ++i) {
        int type = Random::next(1, 4);
        int color = Random::next(0, 7);

        fprintf(inputFile, "%d %d\n", type, color);
        switch (type) {
            case 1:
                int side1, side2, side3;
                generateParalelepipedSides(side1,side2, side3);
                fprintf(inputFile, "%d %d %d\n", side1, side2, side3);
                break;
            case 2:
                int radious;
                generateSphereRadious(radious);
                fprintf(inputFile, "%d\n", radious);
                break;
            case 3:
                int side;
                generateTetrahedromSide( side);
                fprintf(inputFile, "%d\n", side);
                break;
            default:
                continue;
        }
    }
}


void TestGeneretor::generateParalelepipedSides(int& side1, int& side2, int& side3){
    side1 = Random::next(0, 1000);
    side2 = Random::next(0, 1000);
    side3 = Random::next(0, 1000);
}

void TestGeneretor::generateTetrahedromSide(int& side) {
    side = Random::next(0, 1000);
}


void TestGeneretor::generateSphereRadious(int& radious) {
    radious = Random::next(0, 1000);
}