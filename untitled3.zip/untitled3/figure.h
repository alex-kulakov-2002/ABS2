#ifndef __figure__
#define __figure__

#include <stdio.h>
#include "random.h"
#include <stdbool.h>

class Figure {
    int density;

public:
    virtual ~Figure() = default;

    static Figure* InputFigure(FILE* inputFile);

    static Figure *RandomFigure();

    virtual void Input(FILE* inputFile) = 0;

    virtual void InputRnd() = 0;

    virtual void Output(FILE* inputFile) = 0;

    virtual double Volume() = 0;

    void WriteDensityInFile(FILE* outputFile);

};

#endif