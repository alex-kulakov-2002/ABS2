#include "tetrahedron.h"
#include "sphere.h"
#include "parallelepiped.h"




Figure* Figure::InputFigure(FILE* inputFile) {
    int k;
    bool checkType = ProgramException::GetInt(inputFile, &k);
    int density;
    bool checkDensity = ProgramException::GetInt(inputFile, &density);
    if (!checkType || !checkDensity)
        return nullptr;
    Figure* fig = nullptr;
    switch (k) {
        case 1:
            fig = new Tetrahedron;
            break;
        case 3:
            fig = new Sphere;
            break;
        case 2:
            fig = new Parallelepiped;
            break;
        default:
            "Incorrect random value";
    }
    fig->density = density;
    fig->Input(inputFile);

    return fig;
}


Figure* Figure::RandomFigure() {
    auto k = Random::next(1, 4);
    Figure *fig = nullptr;
    switch (k) {
        case 1:
            fig = new Tetrahedron;
            break;
        case 2:
            fig = new Parallelepiped;
            break;
        case 3:
            fig = new Sphere;
            break;
        default:
            "Incorrect random value";
    }
    fig->density = Random::next(1, 1000);
    fig->InputRnd();
    return fig;
}

void Figure::WriteDensityInFile(FILE* outputFile) {
    fprintf(outputFile, "\tDensity: %d\n", density);
}