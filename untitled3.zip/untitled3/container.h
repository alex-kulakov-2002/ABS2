#ifndef __container__
#define __container__

#include <stdio.h>
#include "figure.h"
#include "stdlib.h"

class Container {
public:
    Container();

    ~Container();

    void Input(FILE* inputFile);

    void InputRnd(int size);

    void Output(FILE* outputFile);

    void ShiftByVolume();

    double GetAverageVolume();

private:
    void Clear();

    int len;

    Figure* arr[10001];
};

#endif
