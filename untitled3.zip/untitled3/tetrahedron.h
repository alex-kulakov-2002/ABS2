#ifndef __tetrahedron__
#define __tetrahedron__

#include <stdio.h>
#include "random.h"
#include "figure.h"
#include "exceptions.h"
#include <stdbool.h>

class Tetrahedron: public Figure{
public:
    virtual ~Tetrahedron() {}

    virtual void Input(FILE* inputFile);

    virtual void InputRnd();

    virtual void Output(FILE* outputFile);

    virtual double Volume();

private:
    int side;

};

#endif
