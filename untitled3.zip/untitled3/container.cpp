#include "container.h"



Container::Container() : len{ 0 } {}


Container::~Container() {
    Clear();
}


void Container::Clear() {
    for (int i = 0; i < len; i++) {
        delete arr[i];
        arr[i] = nullptr;
    }
    len = 0;
}


void Container::Input(FILE* inputFile) {
    while ((arr[len] = Figure::InputFigure(inputFile)) != nullptr) {
        len++;
    }
    fclose(inputFile);
}


void Container::InputRnd(int size) {
    while (len < size) {
        if ((arr[len] = Figure::RandomFigure()) != nullptr) {
            len++;
        }
    }
}


void Container::Output(FILE* outputFile) {
    fprintf(outputFile, "Container contains ");
    fprintf(outputFile, "%d", len);
    fprintf(outputFile, " elements.\n");
    for (int i = 0; i < len; i++) {
        fprintf(outputFile, "%d", i + 1);
        fprintf(outputFile, ": ");
        arr[i]->Output(outputFile);
    }
}



double Container::GetAverageVolume() {
    double sum = 0.0;
    for (int i = 0; i < len; i++) {
        sum += arr[i]->Volume();
    }
    return sum / len;
}


void Container::ShiftByVolume() {
    double average = GetAverageVolume();
    int i = 0;
    int j = 0;

    while (j < len) {
        if (arr[j]->Volume() < average) {
            if (i == j) {
                i++;
                j++;
            }
            else {
                j++;
            }
        }
        else {
            if (i >= len) {
                break;
            }
            if (arr[i]->Volume() <= average) {
                struct Figure* f = arr[i];
                arr[i] = arr[j];
                arr[j] = f;
                i++;
                j++;
            }
            else {
                i++;
            }
        }
    }
}



