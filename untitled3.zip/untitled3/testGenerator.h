#ifndef __testgenerator__
#define __testgenerator__

#include <cstdio>
#include "string.h"
#include "random.h"
#include "math.h"
#include "container.h"

class TestGeneretor {
private:
    static void generateParalelepipedSides(int& side1, int& side2, int& side3);

    static void generateSphereRadious(int& radious);

    static void generateTetrahedromSide(int& side);

public:
    static void generateTest(int size);

};

#endif