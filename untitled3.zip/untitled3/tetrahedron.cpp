#include "tetrahedron.h"
#include <math.h>

void Tetrahedron::Input(FILE* inputFile) {
    bool isside = ProgramException::GetInt(inputFile, &side);
    if (isside) {
        printf("Some values was incorrect, so they was changed to zero\n");
    }
}


void Tetrahedron::InputRnd() {
    side = Random::next(0, 1000);
}

void Tetrahedron::Output(FILE* outputFile) {
    fprintf(outputFile, "It is Tetrahedron:\n\t");
    fprintf(outputFile, "side: %d\n\t",side);
    fprintf(outputFile, "Volume = %f\n", Volume());
    WriteDensityInFile(outputFile);
}

double Tetrahedron::Volume() {
    return side * side * side * sqrt(2) / 12;
}