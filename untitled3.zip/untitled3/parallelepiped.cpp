#include "parallelepiped.h"


void Parallelepiped::Input(FILE* inputFile) {
    bool isSide1 = ProgramException::GetInt(inputFile, &side1);
    bool isSide2 = ProgramException::GetInt(inputFile, &side2);
    bool isSide3 = ProgramException::GetInt(inputFile, &side3);
    if (!isSide1 || !isSide2 || !isSide3) {
        printf("Some values was incorrect, so they was changed to zero\n");
    }
}


void Parallelepiped::InputRnd() {
    side1 = Random::next(0, 1000);
    side2 = Random::next(0, 1000);
    side3 = Random::next(0, 1000);
}

void Parallelepiped::Output(FILE* outputFile) {
    fprintf(outputFile, "It is Parallelepiped:\n\t");
    fprintf(outputFile, "side1: %d\n\t", side1);
    fprintf(outputFile, "side2: %d\n\t", side2);
    fprintf(outputFile, "side3: %d\n\t", side3);
    fprintf(outputFile, "Volume = %f\n", Volume());
    WriteDensityInFile(outputFile);
}

double Parallelepiped::Volume() {
    return side1 * side2 * side3;
}