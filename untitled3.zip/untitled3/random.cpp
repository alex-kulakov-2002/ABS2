#include "random.h"

int Random::next(int lower, int upper) {
    if (lower < upper) {
        return rand() % (upper - lower) + lower;
    }
    return 0;
}